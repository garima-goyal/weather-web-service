<?php
return [
        'API_KEY' => '19f9e017b25e49d2b31102206163011',
];