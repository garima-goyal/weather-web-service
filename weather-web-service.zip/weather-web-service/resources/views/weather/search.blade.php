<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Weather Web Service</title>
        
        {!! HTML::style('css/style.css') !!}
          <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
          <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
          <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
                                                                                 
	</head>
	<body>    
    <div class="top-header-section">
    	<div class="top-header-block">
        
    		<div class="top-header-box">
    			<div class="top-content-section">
                
                <div class="top-content-block">
    					<div class="top-content-box">
                        <a href="{{ URL::route('search') }}">Weather</a>
                        <a href="{{ URL::route('show_history') }}">Weather histories</a>
                        </div>
                </div>            
                      {!! Form::open(['route' => ['getHistory'], 'method' => 'post', 'class' => 'form-horizontal ajax_form form-bordered']) !!}
    				<div class="top-content-block">
    					<div class="top-content-box">
    						<h2>Weather</h2>
    						<button type="submit" class="btn btn-default">Get weather History</button>
    					</div>
    					<div class="top-content-bottm-block">
    					<div class="top-content-bottm-section">
    						<label>City Name</label>
    						<input type="text" name="city" id="city" @if($input!='')value="{{$input['city']}}"@endif/>
    					</div>
    					</div>
    					<div class="top-content-bottm-block section">
    					<div class="top-content-bottm-section">
    						<label>Start date</label>
    						<input type="text" name="start_date" id="start_date" @if($input!='')value="{{$input['start_date']}}"@endif/>
    					</div>
    					</div>
    					<div class="top-content-bottm-block section block">
    					<div class="top-content-bottm-section">
    						<label>End Date</label>
    						<input type="text" name="end_date" id="end_date" @if($input!='')value="{{$input['end_date']}}"@endif/>
    					</div>
    					</div>
    				</div>
                 {!! Form::close() !!}
    			</div>
                @if(is_array($data))
    			<div class="middle-section">
    				<div class="middle-block">
                    {!! Form::open(['route' => ['export'], 'method' => 'post', 'class' => 'form-horizontal ajax_form form-bordered']) !!}
    					<div class="btn-secton">
    						<button type="button" class="btn btn-default" name="btnSave" id="btnSave">Save</button>                                                  
    						<button type="submit" class="btn btn-default-sbr" name="btnExport" id="btnExport">Export</button>
                            <input type="hidden" name="exportdata" id="exportdata" @if($data!='') value="{{$jsonresponse}}"@endif />
                          {!! Form::close() !!}
    					</div>
    					<div class="middle-box">
    						<table cellpadding="0" cellspacing="0">
    							<thead>
    								<tr>
    									<th>Date</th>
    									<th>sunrise</th>
    									<th>sunset</th>
    									<th>moonrise</th>
    									<th>moonset</th>
    									<th>maxtemp</th>
                                        <th>mintemp</th>
    								</tr>
    							</thead>
 							
                                @foreach($data as $val) 
                                <tbody>                               
    								<tr>
    									<td>{{$val['date']}}</td>
    									<td>{{$val['sunrise']}}</td>
    									<td>{{$val['sunset']}}</td>
    									<td>{{$val['moonrise']}}</td>
    									<td>{{$val['moonset']}}</td>
    									<td>{{$val['maxtempC']}}</td>
                                        <td>{{$val['mintempC']}}</td>
    								</tr>
    							</tbody>
                                @endforeach    							
    						</table>
    					</div>
    				</div>
    			</div>
                @else
                @if(isset($error) && $error != '')
    			<div class="middle-section">
    				<div class="middle-block">
                    {{$error}}
                    </div>
    			</div>
                @endif
                @endif
    		</div>
            
    
	</body>
</html>

 <script type="text/javascript">
 $(document).ready(function(){
 $("#start_date").datepicker();
 $("#end_date").datepicker();
 });


 $(document).ready(function() {
        $('body').on('submit','.ajax_form',function() {
            city = $('#city').val();
            start_date = $('#start_date').val();
            end_date = $('#end_date').val();
            if(city == '' || start_date == '' || end_date == '')
            {
                alert('Please fill the values');
                return false;
            }
        });
        
        $('#btnSave').click(function(){
			var data = '<?php echo json_encode($data)?>';            
            $.ajax({
            type: 'GET',
            url: "{{ URL::route('saveHistory') }}",
            cache: false,
		   	data : {'data': data},
            success: function(response) {
              	if(response == 'true')
			  	{
					alert("Saved Successfully");
				}  
				else
				{
					alert("failed");
				}
            }
            });
        })
    
 });

 </script>