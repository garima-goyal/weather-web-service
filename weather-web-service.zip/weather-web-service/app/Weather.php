<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Weather extends Model {

    protected $guarded = ['id'];
   	protected $fillable = ['date', 'sunrise', 'sunset', 'moonrise', 'moonset', 'maxtempC', 'maxtempF', 'mintempC', 'mintempF'];
    protected $table = 'history';

  /*  public static function rules($action)
    {
        $rules = [
            'add' => [
                'email'     => 'required|email',
                'name'      => 'required',
                'logo'      => 'image',
                'address'   => 'required',
                'phone_number'=> 'required|numeric',
            ],
            'update' => [
                'email'     => 'required|email',
                'name'      => 'required',
                'logo'      => 'image',
                'address'   => 'required',
                'phone_number'=> 'required|numeric',
            ],
        ];
        return $rules[$action];
    }
*/
}