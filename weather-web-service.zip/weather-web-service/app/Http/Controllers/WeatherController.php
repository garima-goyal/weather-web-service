<?php namespace App\Http\Controllers;

use Illuminate\Html\HtmlFacade;
use Illuminate\Html\FormFacade;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\URL;
use App\Weather;
use Excel;

class WeatherController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('guest');
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('weather.search',['data' => '', 'input' => '']);
	}
    
    
    public function getWeatherHistory(Request $request)
    {
        $api_key = Config::get('constants.API_KEY');
        $city  = $request->input('city');
        $start_date  = $request->input('start_date');
        $end_date  = $request->input('end_date');
        
        $input = array('city' => $city, 'start_date' => $start_date, 'end_date' => $end_date);
            
        $loc_array= Array($city);
        $start_date = date('Y-m-d',strtotime($start_date));   
        $end_date = date('Y-m-d',strtotime($end_date));
        
        $loc_safe=Array();
        foreach($loc_array as $loc){
        	$loc_safe[]= urlencode($loc);
        }
        $loc_string=implode(",", $loc_safe);
        $date_safe=urlencode($start_date);		//this SHOULD return the same value, but if malformed this will correct
        $enddate_safe=urlencode($end_date);		//this SHOULD return the same value, but if malformed this will correct
        
        $premiumurl=sprintf('http://api.worldweatheronline.com/premium/v1/past-weather.ashx?key=%s&q=%s&date=%s&enddate=%s&format=json', 
                    $api_key, $loc_string, $date_safe, $enddate_safe);
  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $premiumurl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER , 1); 
        $response =curl_exec($ch);
        curl_close($ch);
        
        $res = json_decode($response, TRUE);
        $result = '';
        $error = '';
        if(is_array($res))
        {
            $error = '';
            if(isset($res['data']['error']))
            {
                $error = " There is no weather data available for the date provided.";
            }
            else
            {
                $weather = $res['data']['weather'];
                foreach($weather as $val)
                {
                    $result[] = array(
                        'date' => $val['date'],
                        'sunrise' => $val['astronomy'][0]['sunrise'],
                        'sunset' => $val['astronomy'][0]['sunset'],
                        'moonrise' => $val['astronomy'][0]['moonrise'],
                        'moonset' => $val['astronomy'][0]['moonset'],
                        'maxtempC' => $val['maxtempC'],
                        'maxtempF' => $val['maxtempF'],
                        'mintempC' => $val['mintempC'],
                        'mintempF' => $val['mintempF'],
                    //    'uvIndex' => $val['uvIndex'],
                    );
                }
            }        
        }
        
        
        
       // echo "<pre>";
      //  print_r($result); die;
        return view("weather.search")->with(array('data'=>$result, 'input'=> $input, 'jsonresponse' => json_encode($result), 'error' => $error));
      //  return view('weather.search');
    }
    
    
    public function saveWeatherHistory(Request $request)
    {
		$res = $request->Input('data');
		if($res != '')
		{
			$arr = json_decode($res,TRUE);
			//return $arr;
			foreach($arr as $val)
			{
				Weather::create($val);
			}
			return 'true';
		}
		else
		{
			return 'false';
		}
    }
    
    public function exportWeatherHistory(Request $request)
    {
		$res = $request->Input('exportdata');
		if($res != '')
		{
			$data = json_decode($res,TRUE);
            return Excel::create('past-weather-info', function($excel) use ($data) {

		$excel->sheet('mySheet', function($sheet) use ($data)
	    {
			$sheet->fromArray($data);
	    });

	   })->download("pdf");
		}
    }


    public function show_history()
    {
        $result = Weather::all();
        if($result->count()==0)
        $result = '';
        return view("weather.history")->with(array('data'=>$result));
    }

}
