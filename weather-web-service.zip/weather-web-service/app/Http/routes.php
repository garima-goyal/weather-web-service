<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', ['uses'=>'WeatherController@index','as'=>'search']);
Route::post('history', ['uses'=>'WeatherController@getWeatherHistory','as'=>'getHistory']);
Route::get('save', ['uses'=>'WeatherController@saveWeatherHistory','as'=>'saveHistory']);
Route::post('export', ['uses'=>'WeatherController@exportWeatherHistory','as'=>'export']);
Route::get('show_history', ['uses'=>'WeatherController@show_history','as'=>'show_history']);

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
